# CSV Test Cases

A set of CSV files covering common real-world and edge-case scenarios, useful for testing
CSV parsers, importers, or data-processing pipelines.

| File | Scenario |
|---|---|
| 01_basic.csv | Simple, well-formed CSV with a clean header and consistent rows |
| 02_header_only.csv | Header row only, no data rows |
| 03_empty.csv | Completely empty file (0 bytes) |
| 04_quoted_commas.csv | Fields containing commas, wrapped in double quotes |
| 05_escaped_quotes.csv | Fields containing embedded double quotes (escaped as `""`) |
| 06_embedded_newlines.csv | Quoted fields containing embedded newline characters |
| 07_missing_values.csv | Empty/missing field values within otherwise well-formed rows |
| 08_ragged_rows.csv | Rows with inconsistent column counts (too few / too many fields) |
| 09_unicode_special_chars.csv | Non-ASCII names/text, emoji, accented characters, embedded tab |
| 10_numeric_edge_cases.csv | Negative numbers, decimals, scientific notation, leading zeros, currency formatting |
| 11_semicolon_delimited.csv | Semicolon (`;`) used as the delimiter instead of comma |
| 12_tab_delimited.csv | Tab-delimited variant (TSV) |
| 13_duplicate_headers.csv | Duplicate column names in the header row |
| 14_whitespace_and_blank_lines.csv | Leading/trailing whitespace in fields and blank lines between rows |
| 15_crlf_line_endings.csv | Windows-style CRLF (`\r\n`) line endings |
| 16_booleans_and_nulls.csv | Various boolean representations and null-like values (NULL, N/A, NaN, empty) |
| 17_large_dataset.csv | 10,000-row randomly generated dataset for performance/stress testing |

## Notes
- All files use UTF-8 encoding unless otherwise noted (see file 15 for CRLF encoding specifics).
- Files are numbered so tests can be run in order, but each is independent and can be used standalone.
